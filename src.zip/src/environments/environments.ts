export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyA4oRNeswtRYnPlaf_Gg4nmxnS_VECXx68",
        authDomain: "hostachem-c2c9c.firebaseapp.com",
        databaseURL: "https://hostachem-c2c9c.firebaseio.com",
        projectId: "hostachem-c2c9c",
        storageBucket: "hostachem-c2c9c.appspot.com",
        messagingSenderId: "844665094864"
      }
  };